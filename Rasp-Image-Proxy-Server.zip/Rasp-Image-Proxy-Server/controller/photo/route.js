const Router = require('express')
  .Router;
const router = new Router();
const Controller = require('./controller');
const controller = new Controller();

router.route('/')
  .post((req, res) => {
    const datetime = req.body.datetime;
    controller.setDatetime(datetime)
      .then(() => {
        controller.loadDevices()
          .then(() => {
            console.log('copied files successfully!');
            res.status(200).json({
              result: true
            });
          })
          .catch((err) => {
            res.status(500).json({
              message: err.message
            });
          });
      })
      .catch((error) => {
        res.status(500).json({
          message: error.message
        });
      })
  });
module.exports = router;